package gch;

import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

public class JAXBUnMarshall {
	
	public static void main(String[] args) {
		
		 try {
			 
			 	File profesorXML = new File("/home/tmp/profesor.xml");
			 
				JAXBContext jaxbContext = JAXBContext.newInstance(Profesor.class);
		 
				Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
				Profesor profesor = (Profesor) jaxbUnmarshaller.unmarshal(profesorXML);
				
				System.out.println("Datos del profesor");
				System.out.println("Codigo: " + profesor.getCodigo());
				System.out.println("Nombre: " + profesor.getNombre());
				System.out.println("Apellido: " + profesor.getApellido());
				System.out.println("FechaIngreso: " + profesor.getFechaIngreso());
				
			  } catch (JAXBException e) {
				e.printStackTrace();
			  }
		
	}

}
