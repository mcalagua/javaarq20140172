package gch;

import java.io.File;
import java.util.GregorianCalendar;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;

public class JAXBMarshall {
	
	public static void main(String[] args) {
		
		Profesor profesor = new Profesor();
		
		profesor.setCodigo(452334);
		profesor.setNombre("Juan");
		profesor.setApellido("Perez");
		profesor.setFechaIngreso(new GregorianCalendar(2010, 10, 21).getTime());
		
		try {
			
			File profesorXML = new File("/home/tmp/profesor.xml");
			
			JAXBContext jaxbContext = JAXBContext.newInstance(Profesor.class);
			Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
			
			// output pretty printed
			jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			

			jaxbMarshaller.marshal(profesor, profesorXML);
			jaxbMarshaller.marshal(profesor, System.out);
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
