package test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.GregorianCalendar;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.namespace.QName;
import javax.xml.ws.soap.MTOMFeature;

import edu.cibertec.services.Alumno;
import edu.cibertec.services.AlumnoService;
import edu.cibertec.services.AlumnoServiceImplService;

public class TestListarAlumno {

	public static void main(String[] args) 
			throws DatatypeConfigurationException, IOException {
		
		URL wsdl = 
				new URL("http://localhost:8080/Lab3f_JAXWS_MTOM/?wsdl");
		
		//targetNamespace del WSDL
		//name del WSDL
		QName qName = new QName(
				"http://services.cibertec.edu/", 
				"AlumnoServiceImplService");
		
		AlumnoServiceImplService serviceFactory =
				new AlumnoServiceImplService(
						wsdl, qName);
		
		AlumnoService service =
				serviceFactory.getAlumnoServiceImplPort(new MTOMFeature());
		
		List<Alumno> listaAlumnos = service.listarAlumnos();
		
		System.out.println("Resultado : "+
						listaAlumnos.size());
		
		for(Alumno al : listaAlumnos){
			
			System.out.println("Nombres :" + al.getNombres());

			if(al.getFoto() != null){
				
				JFrame frame = new JFrame();
				frame.setSize(512,512);
				
				JLabel label = new JLabel(new ImageIcon(al.getFoto()));
				frame.add(label);
				frame.setVisible(true);
			}

		}

	}
}
