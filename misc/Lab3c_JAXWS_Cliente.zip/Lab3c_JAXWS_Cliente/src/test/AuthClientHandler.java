package test;

import java.io.IOException;
import java.util.Set;

import javax.xml.namespace.QName;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPHeaderElement;
import javax.xml.soap.SOAPMessage;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;

public class AuthClientHandler 
	implements SOAPHandler<SOAPMessageContext> {

	@Override
	public boolean handleMessage(
			SOAPMessageContext context) {
		
		System.out.println("AuthClientHandler...");
		
		Boolean isRequest =
				(Boolean)context.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY);
		
		if(isRequest){
			
			try {
				
			SOAPMessage msg = 
					context.getMessage();
			SOAPEnvelope env = 
					msg.getSOAPPart().getEnvelope();
			SOAPHeader header = env.getHeader();
			
			//Si el mensaje no tiene header
			//se crea uno
			if(header == null){
				header = env.addHeader();
			}
			
			header.
				addNamespaceDeclaration("jaad",
					"http://security/");
			
			QName qUsuario = 
					new QName("http://security/",
							"user","jaad");
			QName qClave = 
					new QName("http://security/",
							"password","jaad");
			
			SOAPHeaderElement hUsuario=
					header.addHeaderElement(qUsuario);
			hUsuario.addTextNode("duke");
			
			SOAPHeaderElement hClave=
					header.addHeaderElement(qClave);
			hClave.addTextNode("java");
			
			//grabar los cambios en el SoapMessage
			msg.saveChanges();
			
			System.out.println("SOAPMessage");
			msg.writeTo(System.out);

			} catch (SOAPException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
	
		}
		
		return true;
	}

	@Override
	public boolean handleFault(SOAPMessageContext context) {
		return false;
	}

	@Override
	public void close(MessageContext context) {
	
	}

	@Override
	public Set<QName> getHeaders() {
		return null;
	}

}
