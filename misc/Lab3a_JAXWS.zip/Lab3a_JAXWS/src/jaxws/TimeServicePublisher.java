package jaxws;

import javax.xml.ws.Endpoint;

public class TimeServicePublisher {

	public static void main(String[] args) {
		
		Endpoint.publish("http://localhost:9876/timeService", 
				new TimeServiceImpl());
				
		System.out.println("Publish service");
		
	}
	
}
