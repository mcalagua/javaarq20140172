package jaxws;

import java.util.Date;

import javax.jws.WebService;

@WebService(endpointInterface = "jaxws.TimeService")
public class TimeServiceImpl 
				implements TimeService{

	public String getTimeAsString() {
		return new Date().toString();
	}

	public long getTimeAsElapsed() {
		return new Date().getTime();
	}

}
