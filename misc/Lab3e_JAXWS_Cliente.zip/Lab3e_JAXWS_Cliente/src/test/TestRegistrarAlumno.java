package test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.namespace.QName;

import edu.cibertec.services.Alumno;
import edu.cibertec.services.AlumnoService;
import edu.cibertec.services.AlumnoServiceImplService;

public class TestRegistrarAlumno {

	public static void main(String[] args) 
			throws DatatypeConfigurationException, IOException {
		
		URL wsdl = 
				new URL("http://localhost:8080/Lab3e_JAXWS_Base64Encoding/?wsdl");
		
		//targetNamespace del WSDL
		//name del WSDL
		QName qName = new QName(
				"http://services.cibertec.edu/", 
				"AlumnoServiceImplService");
		
		AlumnoServiceImplService serviceFactory =
				new AlumnoServiceImplService(
						wsdl, qName);
		
		AlumnoService service =
				serviceFactory.getAlumnoServiceImplPort();
		
		Alumno alumno = new Alumno();
		alumno.setNombres("Carlos 2");
		alumno.setApellidos("Alcantara 2");
		alumno.setFechaNacimiento(		
			DatatypeFactory.newInstance().
			newXMLGregorianCalendar(
			new GregorianCalendar(1961, 02, 11))
		);
		
		FileInputStream foto = new FileInputStream(new File("/home/tmp/duke.jpe"));	
		byte[] bytesFoto = new byte[foto.available()];
		foto.read(bytesFoto);
		foto.close();
		
		alumno.setFoto(bytesFoto);
		
		String resultado = 
				service.registrar(alumno);
		
		System.out.println("Resultado : "+
						resultado);
	}
}
