
package edu.cibertec.services;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the edu.cibertec.services package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ListarAlumnos_QNAME = new QName("http://services.cibertec.edu/", "listarAlumnos");
    private final static QName _ListarAlumnosResponse_QNAME = new QName("http://services.cibertec.edu/", "listarAlumnosResponse");
    private final static QName _RegistrarResponse_QNAME = new QName("http://services.cibertec.edu/", "registrarResponse");
    private final static QName _Registrar_QNAME = new QName("http://services.cibertec.edu/", "registrar");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: edu.cibertec.services
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link RegistrarResponse }
     * 
     */
    public RegistrarResponse createRegistrarResponse() {
        return new RegistrarResponse();
    }

    /**
     * Create an instance of {@link ListarAlumnos }
     * 
     */
    public ListarAlumnos createListarAlumnos() {
        return new ListarAlumnos();
    }

    /**
     * Create an instance of {@link Registrar }
     * 
     */
    public Registrar createRegistrar() {
        return new Registrar();
    }

    /**
     * Create an instance of {@link Alumno }
     * 
     */
    public Alumno createAlumno() {
        return new Alumno();
    }

    /**
     * Create an instance of {@link ListarAlumnosResponse }
     * 
     */
    public ListarAlumnosResponse createListarAlumnosResponse() {
        return new ListarAlumnosResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListarAlumnos }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.cibertec.edu/", name = "listarAlumnos")
    public JAXBElement<ListarAlumnos> createListarAlumnos(ListarAlumnos value) {
        return new JAXBElement<ListarAlumnos>(_ListarAlumnos_QNAME, ListarAlumnos.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListarAlumnosResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.cibertec.edu/", name = "listarAlumnosResponse")
    public JAXBElement<ListarAlumnosResponse> createListarAlumnosResponse(ListarAlumnosResponse value) {
        return new JAXBElement<ListarAlumnosResponse>(_ListarAlumnosResponse_QNAME, ListarAlumnosResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RegistrarResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.cibertec.edu/", name = "registrarResponse")
    public JAXBElement<RegistrarResponse> createRegistrarResponse(RegistrarResponse value) {
        return new JAXBElement<RegistrarResponse>(_RegistrarResponse_QNAME, RegistrarResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Registrar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.cibertec.edu/", name = "registrar")
    public JAXBElement<Registrar> createRegistrar(Registrar value) {
        return new JAXBElement<Registrar>(_Registrar_QNAME, Registrar.class, null, value);
    }

}
