package jaxrs;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/timeService")
public interface TimeResource {
	
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String getTimeText();

	@GET
	@Produces(MediaType.TEXT_HTML)
	public String getTimeHtml();
	
	@GET
	@Produces(MediaType.TEXT_XML)
	public String getTimeXml();
	
}
