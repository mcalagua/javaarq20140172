package jaxrs.impl;
import java.util.Date;
import javax.ws.rs.Path;
import jaxrs.TimeResource;

@Path("/timeService")
public class TimeResourceService 
			implements TimeResource{

	public String getTimeText() {
		return new Date().toString();
	}
	

	public String getTimeHtml() {

		String resultado = 
				"<html>" +
				"<body><h1>"+
				new Date().toString()+
				"</h1></body></html>";
		
		return resultado;
		
	}

	public String getTimeXml() {
		
		String resultado = 
				"<?xml version=\"1.0\"?>" +
				"<time>"+
				new Date().toString() +
				"</time>";
		
		return resultado;
	}

}
