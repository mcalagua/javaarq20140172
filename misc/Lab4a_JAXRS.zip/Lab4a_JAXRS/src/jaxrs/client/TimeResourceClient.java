package jaxrs.client;

import java.net.URI;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriBuilder;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;

public class TimeResourceClient {

	public static void main(String[] args) {
	
	//1 Obtenemos la ubicacion del servicio REST
		URI serviceLocation = 	
			UriBuilder.fromUri("" +
			"http://localhost:8080/Lab4a_JAXRS").build();
		
	//2 Creamos el cliente
		ClientConfig config = 
				new DefaultClientConfig();
		Client client = Client.create(config);
		
	//3 Indicamos que recurso debe obtener el cliente	
		WebResource service = 
				client.resource(serviceLocation);
		
	//4.a Obtenemos el recurso web en TEXT_PLAIN
		System.out.println(
			service.
				path("rest").
				path("timeService").
				accept(MediaType.TEXT_PLAIN).
				get(String.class)
		);
		
	//4.b Obtenemos el recurso web en TEXT_XML
		System.out.println(
			service.
				path("rest").
				path("timeService").
				accept(MediaType.TEXT_XML).
				get(String.class)
		);
		
	//4.c Obtenemos el recurso web en TEXT_HTML
	//    como lo haria un browser en HTML
		System.out.println(
			service.
				path("rest").
				path("timeService").
				accept(MediaType.TEXT_HTML).
				get(String.class)
		);
		
	}

}
