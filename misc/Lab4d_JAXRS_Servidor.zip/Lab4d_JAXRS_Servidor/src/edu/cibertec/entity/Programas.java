package edu.cibertec.entity;

import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "programas")
public class Programas {

	protected List<Programa> programas;
	protected List<Link> links;

	@XmlElementRef
	public List<Programa> getProgramas() {
		return programas;
	}

	public void setPrograms(List<Programa> programas) {
		this.programas = programas;
	}

	@XmlElementRef
	public List<Link> getLinks() {
		return links;
	}

	public void setLinks(List<Link> links) {
		this.links = links;
	}

}
