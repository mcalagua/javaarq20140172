package edu.cibertec.services.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;

import com.sun.jersey.core.header.FormDataContentDisposition;
import com.sun.jersey.multipart.FormDataParam;

import edu.cibertec.entity.Link;
import edu.cibertec.entity.Profesor;
import edu.cibertec.entity.Programa;
import edu.cibertec.entity.Programas;
import edu.cibertec.services.ProgramasResource;
import edu.cibertec.utils.MysqlDBConn;

@Path("/programas")
public class ProgramasResourceService implements ProgramasResource {

	private AtomicInteger generadorId = new AtomicInteger();

	public Programa getPrograma(String idPrograma) {

		System.out.println("Buscando programa " + idPrograma + " ["
				+ this.hashCode() + "]");
		Connection connection = null;
		Programa programa = null;

		try {

			connection = MysqlDBConn.getConnection();
			PreparedStatement pst = connection
					.prepareStatement("SELECT * FROM TB_PROGRAMA "
							+ "where idPrograma = ?");
			pst.setString(1, idPrograma);
			ResultSet rs = pst.executeQuery();

			if (rs.next()) {
				programa = new Programa();
				programa.setIdPrograma(rs.getString(1));
				programa.setNombre(rs.getString(2));
				programa.setDuracionHoras(rs.getDouble(3));
				programa.setHorario(rs.getString(4));
				programa.setFechaInicio(new Date(rs.getDate(5).getTime()));
				programa.setFechaFin(new Date(rs.getDate(6).getTime()));

			} else {
				throw new WebApplicationException(Response.Status.NOT_FOUND);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {

			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

		}

		return programa;
	}

	private String generaId() {
		return System.currentTimeMillis() + "-" + generadorId.incrementAndGet();
	}

	public Response createPrograma(Programa programa) {

		System.out.println("Registrando programa:" + programa.getNombre()
				+ " [" + this.hashCode() + "]");

		Connection connection = null;
		String idPrograma = generaId();

		try {

			connection = MysqlDBConn.getConnection();
			PreparedStatement pst = connection
					.prepareStatement("INSERT INTO "
							+ "TB_PROGRAMA (idPrograma,nombre,duracionHoras,horario,fechaInicio,fechaFin,idProfesor) "
							+ "values (?,?,?,?,?,?,?)");

			pst.setString(1, idPrograma);
			pst.setString(2, programa.getNombre());
			pst.setDouble(3, programa.getDuracionHoras());
			pst.setString(4, programa.getHorario());
			pst.setDate(5, new java.sql.Date(programa.getFechaInicio()
					.getTime()));
			pst.setDate(6, new java.sql.Date(programa.getFechaFin().getTime()));
			pst.setInt(7, programa.getProfesor().getIdProfesor());

			int resultado = pst.executeUpdate();

			if (resultado != 1) {
				throw new WebApplicationException(
						Response.Status.INTERNAL_SERVER_ERROR);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {

			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return Response.created(URI.create(idPrograma)).build();
	}

	public Programas getProgramas(int start, int size, UriInfo uriInfo,
			HttpHeaders httpHeaders) {

		// for(String header : httpHeaders.getRequestHeaders().keySet()){
		// System.out.println(header);
		// }

		String accept = httpHeaders.getRequestHeader("accept").get(0);

		UriBuilder builder = uriInfo.getAbsolutePathBuilder();
		builder.queryParam("start", "{start}");
		builder.queryParam("size", "{size}");

		System.out.println("Listando programas [" + this.hashCode() + "] "
				+ accept);

		Programas programas = null;
		Connection connection = null;

		List<Programa> listaProgramas = new ArrayList<Programa>();
		List<Link> links = new ArrayList<Link>();

		try {

			connection = MysqlDBConn.getConnection();

			PreparedStatement pst = connection
					.prepareStatement("SELECT COUNT(1) FROM TB_PROGRAMA");

			ResultSet rs = pst.executeQuery();

			rs.next();

			int totalProgramas = rs.getInt(1);

			System.out.println("Cantidad total de programas:" + totalProgramas);

			pst = connection
					.prepareStatement("SELECT * FROM TB_PROGRAMA LIMIT ?,?");

			pst.setInt(1, start);
			pst.setInt(2, size);

			rs = pst.executeQuery();
			Programa programa = null;

			while (rs.next()) {
				programa = new Programa();
				programa.setIdPrograma(rs.getString(1));
				programa.setNombre(rs.getString(2));
				programa.setDuracionHoras(rs.getDouble(3));
				programa.setHorario(rs.getString(4));
				programa.setFechaInicio(new Date(rs.getDate(5).getTime()));
				programa.setFechaFin(new Date(rs.getDate(6).getTime()));

				String profesorId = rs.getString(7);

				if (profesorId != null) {
					UriBuilder profesorBuilder = uriInfo.getBaseUriBuilder();
					String profesorUrl = profesorBuilder.clone()
							.path("profesores").path(profesorId).build()
							.toString();
					Link linkProfesor = new Link("self", profesorUrl, accept);
					Profesor profe = new Profesor();
					profe.setLink(linkProfesor);
					programa.setProfesor(profe);
				}

				listaProgramas.add(programa);
			}

			// next link
			if (start + size < totalProgramas) {

				int next = start + size;
				URI nextUri = builder.clone().build(next, size);
				Link nextLink = new Link("next", nextUri.toString(), accept);
				links.add(nextLink);

			}

			// previous link
			if (start > 0) {
				int previous = start - size;
				if (previous < 0)
					previous = 0;
				URI previousUri = builder.clone().build(previous, size);
				Link previousLink = new Link("previous",
						previousUri.toString(), accept);
				links.add(previousLink);
			}

			programas = new Programas();
			programas.setPrograms(listaProgramas);
			programas.setLinks(links);

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {

			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

		}

		return programas;
	}

//	public Response uploadSyllabus(
//			String idPrograma,
//			byte[] bytes) {
//		
//		System.out.println("Actualizando sillabys " + idPrograma);
//		
//		Connection connection = null;
//
//		try {
//
//			connection = MysqlDBConn.getConnection();
//			PreparedStatement pst = connection
//					.prepareStatement("UPDATE TB_PROGRAMA "
//							+ "set syllabus = ? "
//							+ "where idPrograma = ?");
//
//			pst.setBytes(1,bytes);
//			pst.setString(2, idPrograma);
//			
//			int resultado = pst.executeUpdate();
//
//			if (resultado != 1) {
//				throw new WebApplicationException(
//						Response.Status.INTERNAL_SERVER_ERROR);
//			}
//
//		} catch (SQLException e) {
//			e.printStackTrace();
//		} finally {
//
//			if (connection != null) {
//				try {
//					connection.close();
//				} catch (SQLException e) {
//					e.printStackTrace();
//				}
//			}
//		}
//		
//		return Response.noContent().build();
//	}

	public byte[] downloadSyllabus(
			String idPrograma) {
		
		System.out.println("descargando syllabus " + idPrograma);
		
		Connection connection = null;
		byte[] syllabus = null;

		try {

			connection = MysqlDBConn.getConnection();

			PreparedStatement pst = connection
					.prepareStatement("SELECT syllabus from TB_PROGRAMA "
							+ "where idPrograma = ?");

			pst.setString(1, idPrograma);
			
			ResultSet rs = pst.executeQuery();
			
			if(rs.next()){				
				
				syllabus = rs.getBytes(1);		
				
			}else{
				
				throw new WebApplicationException(
						Response.Status.NOT_FOUND);
			}
			return syllabus;
		/*  return Response
				    .ok(syllabus, MediaType.APPLICATION_OCTET_STREAM)
				    .header("content-disposition", "attachment; filename = syllabus.docx").build();*/

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {

			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
		return null;

	}


//	public Response uploadSyllabus(
//		InputStream uploadedInputStream,
//		FormDataContentDisposition fileDetail,
//		String idPrograma) {
//		
//		System.out.println("Actualizando syllabus " + idPrograma);
//		
//		Connection connection = null;
//
//		try {
//
//			connection = MysqlDBConn.getConnection();
//			PreparedStatement pst = connection
//					.prepareStatement("UPDATE TB_PROGRAMA "
//							+ "set syllabus = ? "
//							+ "where idPrograma = ?");
//			
//			System.out.println(fileDetail.getFileName());
//			System.out.println(fileDetail.getSize());
//			System.out.println(fileDetail.getName());
//			
//			byte[] bytes = new byte[uploadedInputStream.available()];			
//
//			System.out.println("Bytes : " + uploadedInputStream.available());
//			
//			uploadedInputStream.read(bytes);
//			
//
//			System.out.println("Bytes : " + bytes.length);
//			
//			uploadedInputStream.close();
//
//			
//			pst.setBytes(1,bytes);
//			pst.setString(2, idPrograma);
//			
//			int resultado = pst.executeUpdate();
//
//			if (resultado != 1) {
//				throw new WebApplicationException(
//						Response.Status.INTERNAL_SERVER_ERROR);
//			}
//
//		} catch (SQLException e) {
//			e.printStackTrace();
//		} catch (IOException e) {
//			e.printStackTrace();
//		} finally {
//
//			if (connection != null) {
//				try {
//					connection.close();
//				} catch (SQLException e) {
//					e.printStackTrace();
//				}
//			}
//		}
//		
//		return Response.noContent().build();
//		
//	}

	public Response uploadSyllabus(
			File file,
			String idPrograma) {
		
		System.out.println("Actualizando syllabus " + idPrograma);
		
		Connection connection = null;

		try {

			connection = MysqlDBConn.getConnection();
			PreparedStatement pst = connection
					.prepareStatement("UPDATE TB_PROGRAMA "
							+ "set syllabus = ? "
							+ "where idPrograma = ?");
	
			FileInputStream fis = new FileInputStream(file);		
			byte[] bytes = new byte[(int) file.length()];
			fis.read(bytes);		
			System.out.println("Bytes : " + bytes.length);
			
			pst.setBytes(1,bytes);
			pst.setString(2, idPrograma);
			
			int resultado = pst.executeUpdate();
			
			fis.close();
			
			if (resultado != 1) {
				throw new WebApplicationException(
						Response.Status.INTERNAL_SERVER_ERROR);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {

			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}	

		return Response.noContent().build();
	}
	
}
