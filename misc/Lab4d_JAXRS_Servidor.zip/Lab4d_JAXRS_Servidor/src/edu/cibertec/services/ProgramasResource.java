package edu.cibertec.services;

import java.io.File;
import java.io.InputStream;

import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import com.sun.jersey.core.header.FormDataContentDisposition;
import com.sun.jersey.multipart.FormDataParam;

import edu.cibertec.entity.Programa;
import edu.cibertec.entity.Programas;

@Path("/programas")
public interface ProgramasResource {
	
	//@GET
	//@Produces({MediaType.TEXT_XML,MediaType.APPLICATION_JSON })
	//public List<Programa> getProgramas();
	
	@GET
	@Produces({MediaType.TEXT_XML,MediaType.APPLICATION_JSON })
	public Programas getProgramas(
			@QueryParam("start") int start,
            @QueryParam("size") @DefaultValue("2") int size,
            @Context UriInfo uriInfo,
            @Context HttpHeaders httpHeaders);
	
	@GET
	@Path("{id}")
	@Produces({MediaType.TEXT_XML,MediaType.APPLICATION_JSON})
	public Programa getPrograma(
			@PathParam("id") String idPrograma);
	
	@POST
	@Consumes({MediaType.TEXT_XML,MediaType.APPLICATION_JSON})
	public Response createPrograma(Programa programa);
	
	@POST
	@Path("{id}")
	public Response uploadSyllabus(File file,@PathParam("id") String idPrograma);	
//	@PUT
//	@Path("{id}")
//	@Consumes(MediaType.WILDCARD)
//	public Response uploadSyllabus(
//			@PathParam("id") String idPrograma,
//			byte[] inputStream);
	
	
//	@POST
//	@Path("{id}")
//	@Consumes(MediaType.MULTIPART_FORM_DATA)
//	public Response uploadSyllabus(
//		@FormDataParam("file") InputStream uploadedInputStream,
//		@FormDataParam("file") FormDataContentDisposition fileDetail,
//		@PathParam("id") String idPrograma);
	
	@GET
	@Path("{id}")
	@Produces(MediaType.APPLICATION_OCTET_STREAM)
	public byte[] downloadSyllabus(
			@PathParam("id") String idPrograma);
	
//	@GET
//	@Path("{id}")
//	@Produces(MediaType.WILDCARD)
//	public Response downloadSyllabus(
//			@PathParam("id") String idPrograma);
}
