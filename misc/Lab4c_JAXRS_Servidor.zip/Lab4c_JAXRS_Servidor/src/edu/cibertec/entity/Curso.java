package edu.cibertec.entity;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Curso {
	
	private String idModulo;
	private String nombre;
	private Double duracionHoras;
	private String requisitos;
	private String formulaEvaluacion;
	
	public String getIdModulo() {
		return idModulo;
	}
	public void setIdModulo(String idModulo) {
		this.idModulo = idModulo;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public Double getDuracionHoras() {
		return duracionHoras;
	}
	public void setDuracionHoras(Double duracionHoras) {
		this.duracionHoras = duracionHoras;
	}
	public String getRequisitos() {
		return requisitos;
	}
	public void setRequisitos(String requisitos) {
		this.requisitos = requisitos;
	}
	public String getFormulaEvaluacion() {
		return formulaEvaluacion;
	}
	public void setFormulaEvaluacion(String formulaEvaluacion) {
		this.formulaEvaluacion = formulaEvaluacion;
	}

	
	
}
