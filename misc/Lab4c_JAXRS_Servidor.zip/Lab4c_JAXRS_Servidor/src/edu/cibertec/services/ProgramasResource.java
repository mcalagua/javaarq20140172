package edu.cibertec.services;

import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import edu.cibertec.entity.Programa;
import edu.cibertec.entity.Programas;

@Path("/programas")
public interface ProgramasResource {
	
	//@GET
	//@Produces({MediaType.TEXT_XML,MediaType.APPLICATION_JSON })
	//public List<Programa> getProgramas();
	
	@GET
	@Produces({MediaType.TEXT_XML,MediaType.APPLICATION_JSON })
	public Programas getProgramas(
			@QueryParam("start") int start,
            @QueryParam("size") @DefaultValue("2") int size,
            @Context UriInfo uriInfo,
            @Context HttpHeaders httpHeaders);
	
	@GET
	@Path("{id}")
	@Produces({MediaType.TEXT_XML,MediaType.APPLICATION_JSON})
	public Programa getPrograma(
			@PathParam("id") String idPrograma);
	
	@POST
	@Consumes({MediaType.TEXT_XML,MediaType.APPLICATION_JSON})
	public Response createPrograma(Programa programa);

}
