package edu.cibertec.client;

import java.net.URI;
import java.util.List;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriBuilder;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.GenericType;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;

public class RESTClientGet {

	public static void main(String[] args) {
	
	//1 Obtenemos la ubicacion del servicio REST
		URI serviceLocation = 	
			UriBuilder.fromUri("" +
			"http://localhost:8080/Lab4c_JAXRS_Servidor").build();
		
	//2 Creamos el cliente
		ClientConfig config = 
				new DefaultClientConfig();
		Client client = Client.create(config);
		
		
	//3 Indicamos que recurso con el cual se va a interactuar	
		WebResource service = 
				client.resource(serviceLocation);
		
	//4 Se envian la peticiones al servidor con metodos GET
		System.out.println(
	    		service.
	    		path("rest").
	    		path("programas").
	        	accept(MediaType.TEXT_XML).
	        	get(String.class)	    
		);
		
	    List<Programa> listaXML = 
	    		service.
	    		path("rest").
	    		path("programas").
	        	accept(MediaType.TEXT_XML).
	        	get(new GenericType<List<Programa>>(){});

	    System.out.println("Lista Programas:" + listaXML.size());
	    
	    for(Programa programa : listaXML){
	    	System.out.println("----------------------------------------------");
	    	System.out.println("IDPrograma:" + programa.getIdPrograma());
	    	System.out.println("Nombre:" + programa.getNombre());
	    	System.out.println("FechaInicio:" + programa.getFechaInicio());
	    	System.out.println("FechaFin:" + programa.getFechaFin());
	    }
	    	    
		System.out.println(
	    		service.
	    		path("rest").
	    		path("programas").
	        	accept(MediaType.APPLICATION_JSON).
	        	get(String.class)	    
		);
		
	    List<Programa> listaJSON = 
	    		service.
	    		path("rest").
	    		path("programas").
	        	accept(MediaType.APPLICATION_JSON).
	        	get(new GenericType<List<Programa>>(){});

	    System.out.println("Lista Programas:" + listaJSON.size());
	    
	    for(Programa programa : listaJSON){
	    	System.out.println("----------------------------------------------");
	    	System.out.println("IDPrograma:" + programa.getIdPrograma());
	    	System.out.println("Nombre:" + programa.getNombre());
	    	System.out.println("FechaInicio:" + programa.getFechaInicio());
	    	System.out.println("FechaFin:" + programa.getFechaFin());
	    }	      
	}
}
