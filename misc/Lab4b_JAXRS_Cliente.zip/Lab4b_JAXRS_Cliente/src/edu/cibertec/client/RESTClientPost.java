package edu.cibertec.client;

import java.net.URI;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.List;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriBuilder;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;

public class RESTClientPost {

	public static void main(String[] args) {
	
	//1 Obtenemos la ubicacion del servicio REST
		URI serviceLocation = 	
			UriBuilder.fromUri("" +
			"http://localhost:8080/Lab4b_JAXRS_Servidor").build();
		
	//2 Creamos el cliente
		ClientConfig config = 
				new DefaultClientConfig();
		Client client = Client.create(config);
		
	//3 Indicamos que recurso con el cual se va a interactuar	
		WebResource service = 
				client.resource(serviceLocation);
   
		Programa programa = new Programa();
		programa.setNombre("REST Application Developer");
		programa.setHorario("Domingos");
		programa.setDuracionHoras(50.0);
		programa.setFechaInicio(new GregorianCalendar(2013, 4, 8).getTime());
		programa.setFechaFin(new GregorianCalendar(2013, 6, 8).getTime());

	//4 Se envia la peticion al servidor con el metodo POST y
	//  se obtiene los datos de respuesta HTTP
	    ClientResponse response = 
	    		service.
	    		path("rest").
	    		path("programas").
	        	type(MediaType.APPLICATION_JSON)
	        	.post(ClientResponse.class, programa);
	    
	    System.out.println("HTTP status : " + response.getStatus());
	    System.out.println("HTTP response : " + response.getClientResponseStatus());
	    
	    Iterator<List<String>> iterator = response.getHeaders().values().iterator();
	    
	    while(iterator.hasNext()){
	    	System.out.println("HTTP headers: " + iterator.next());
	    }  	
	}
}
