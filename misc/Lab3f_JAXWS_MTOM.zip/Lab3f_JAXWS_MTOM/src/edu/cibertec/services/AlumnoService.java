package edu.cibertec.services;

import java.util.List;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import edu.cibertec.entity.Alumno;

@WebService
public interface AlumnoService {
	
	@WebMethod
	@WebResult(name="respuesta")
	public String registrar(
			@WebParam(name="alumno") Alumno alumno);
	
	@WebMethod
	@WebResult(name="alumno")
	public List<Alumno> listarAlumnos();

}
