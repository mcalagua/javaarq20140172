package edu.cibertec.services;

import java.io.ByteArrayInputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.jws.WebService;
import javax.naming.BinaryRefAddr;
import javax.xml.ws.soap.MTOM;

import sun.misc.FpUtils;

import com.sun.xml.internal.ws.util.ByteArrayDataSource;

import edu.cibertec.entity.Alumno;
import edu.cibertec.utils.MysqlDBConn;

@MTOM
@WebService(
		endpointInterface=
			"edu.cibertec.services.AlumnoService")
public class AlumnoServiceImpl 
	implements AlumnoService{

	public String registrar(Alumno alumno) {
	
		System.out.println("Metodo registrar alumno");
		
		String respuesta = "";
		Connection conexion = null;
		
		try {
			
		conexion = MysqlDBConn.getConnection();
		
		PreparedStatement pst =
			conexion.prepareStatement(
			"INSERT INTO " +
			"TB_ALUMNO (nombres,apellidos,fechaNacimiento,foto) " +
			"values (?,?,?,?)");
			
		pst.setString(1, alumno.getNombres());
		pst.setString(2, alumno.getApellidos());
		pst.setDate(3, 
				new java.sql.Date(
				alumno.getFechaNacimiento().getTime()));
		
		DataHandler foto = alumno.getFoto();
		
		System.out.println("Foto:" + foto.getName());
		System.out.println("Content-Type:" + foto.getContentType());
		
		pst.setBinaryStream(4, foto.getInputStream());
		
		int resultado = pst.executeUpdate();
		
		if(resultado == 1){
			respuesta = "Alumno registrado OK";
		}
			
		} catch (Exception e) {
			respuesta = e.getMessage();
			e.printStackTrace();
		} finally{			
			if(conexion!=null){
				try {
				conexion.close();
				} catch (SQLException e) {
				e.printStackTrace();
				}
			}	
		}
		return respuesta;
	}

	public List<Alumno> listarAlumnos() {

	System.out.println("Listando profesores ");
		
		List<Alumno> listaAlumnos = null;
		Connection connection = null;

		try {
			
			connection = MysqlDBConn.getConnection();
			
			PreparedStatement pst = 
					connection.prepareStatement("SELECT * FROM TB_ALUMNO");

			ResultSet rs = pst.executeQuery();
			
			listaAlumnos = new ArrayList<Alumno>();
			
			Alumno alumno = null;
			
			while (rs.next()){
				
				alumno = new Alumno();
				alumno.setIdAlumno(rs.getInt(1));
				alumno.setNombres(rs.getString(2));
				alumno.setApellidos(rs.getString(3));		
				alumno.setFechaNacimiento(new Date(rs.getDate(4).getTime()));

				byte[] fotoBytes = rs.getBytes(5);
				
				if(fotoBytes != null){
					
					ByteArrayDataSource byteArrayDataSource = new ByteArrayDataSource(rs.getBytes(5),"");	
					DataHandler foto = new DataHandler(byteArrayDataSource);				
					alumno.setFoto(foto);
					
				}
		
				listaAlumnos.add(alumno);
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		} finally{
	
			if(connection!=null){
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			
		}
		
		return listaAlumnos;
		
	}

}
