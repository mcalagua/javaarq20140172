
package edu.cibertec.services.jaxws;

import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "listarAlumnosResponse", namespace = "http://services.cibertec.edu/")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "listarAlumnosResponse", namespace = "http://services.cibertec.edu/")
public class ListarAlumnosResponse {

    @XmlElement(name = "alumno", namespace = "")
    private List<edu.cibertec.entity.Alumno> alumno;

    /**
     * 
     * @return
     *     returns List<Alumno>
     */
    public List<edu.cibertec.entity.Alumno> getAlumno() {
        return this.alumno;
    }

    /**
     * 
     * @param alumno
     *     the value for the alumno property
     */
    public void setAlumno(List<edu.cibertec.entity.Alumno> alumno) {
        this.alumno = alumno;
    }

}
