
package edu.cibertec.services.jaxws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "listarAlumnos", namespace = "http://services.cibertec.edu/")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "listarAlumnos", namespace = "http://services.cibertec.edu/")
public class ListarAlumnos {


}
