
package edu.cibertec.services.jaxws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "registrarResponse", namespace = "http://services.cibertec.edu/")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "registrarResponse", namespace = "http://services.cibertec.edu/")
public class RegistrarResponse {

    @XmlElement(name = "respuesta", namespace = "")
    private String respuesta;

    /**
     * 
     * @return
     *     returns String
     */
    public String getRespuesta() {
        return this.respuesta;
    }

    /**
     * 
     * @param respuesta
     *     the value for the respuesta property
     */
    public void setRespuesta(String respuesta) {
        this.respuesta = respuesta;
    }

}
