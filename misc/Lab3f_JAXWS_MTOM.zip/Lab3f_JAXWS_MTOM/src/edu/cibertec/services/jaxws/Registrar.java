
package edu.cibertec.services.jaxws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "registrar", namespace = "http://services.cibertec.edu/")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "registrar", namespace = "http://services.cibertec.edu/")
public class Registrar {

    @XmlElement(name = "alumno", namespace = "")
    private edu.cibertec.entity.Alumno alumno;

    /**
     * 
     * @return
     *     returns Alumno
     */
    public edu.cibertec.entity.Alumno getAlumno() {
        return this.alumno;
    }

    /**
     * 
     * @param alumno
     *     the value for the alumno property
     */
    public void setAlumno(edu.cibertec.entity.Alumno alumno) {
        this.alumno = alumno;
    }

}
