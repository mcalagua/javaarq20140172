package edu.cibertec.handler.wss;

import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.UnsupportedCallbackException;

import com.sun.xml.wss.impl.callback.PasswordValidationCallback;

// Verifier handles service-side callbacks for password validation.
public class Verifier implements CallbackHandler {

	// For password validation, set the validator to the inner class below.
	public void handle(Callback[] callbacks)
			throws UnsupportedCallbackException {
		for (int i = 0; i < callbacks.length; i++) {
			if (callbacks[i] instanceof PasswordValidationCallback) {
				PasswordValidationCallback cb = (PasswordValidationCallback) callbacks[i];
				
				if (cb.getRequest() instanceof PasswordValidationCallback.DigestPasswordRequest)
					cb.setValidator(new WSSPasswordValidator());
				
			} else
				throw new UnsupportedCallbackException(null, "Not needed");
		}
	}
	
}
