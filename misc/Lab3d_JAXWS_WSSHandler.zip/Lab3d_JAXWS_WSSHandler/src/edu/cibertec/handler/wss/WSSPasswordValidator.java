package edu.cibertec.handler.wss;

import com.sun.xml.wss.impl.callback.PasswordValidationCallback;
import com.sun.xml.wss.impl.callback.PasswordValidationCallback.DigestPasswordValidator;
import com.sun.xml.wss.impl.callback.PasswordValidationCallback.PasswordValidationException;
import com.sun.xml.wss.impl.callback.PasswordValidationCallback.Request;

public class WSSPasswordValidator implements PasswordValidationCallback.PasswordValidator{
	
	private static final String PASSWORD = "linux";
	
	@Override
	public boolean validate(Request req) throws PasswordValidationException {

		PasswordValidationCallback.DigestPasswordRequest digestPwd = (PasswordValidationCallback.DigestPasswordRequest) req;
		
		System.out.println("Encrypted Username : " + digestPwd.getUsername());
		System.out.println("Encrypted Password : " + digestPwd.getPassword());
		System.out.println("Encrypted Digest : " +digestPwd.getDigest());
		System.out.println("Encrypted Created : " +digestPwd.getCreated());
		System.out.println("Encrypted Nonce : " +digestPwd.getNonce());
		
		//Seteamos el password real para que se compare a traves del hashing
		digestPwd.setPassword(PASSWORD);
		
		DigestPasswordValidator validator = new DigestPasswordValidator();
		
		return validator.validate(digestPwd);
		
	}

}
