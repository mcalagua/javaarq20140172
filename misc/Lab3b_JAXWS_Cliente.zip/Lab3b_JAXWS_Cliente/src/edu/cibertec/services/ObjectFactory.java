
package edu.cibertec.services;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the edu.cibertec.services package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _RegistrarProfesor_QNAME = new QName("http://services.cibertec.edu/", "registrarProfesor");
    private final static QName _RegistrarProfesorResponse_QNAME = new QName("http://services.cibertec.edu/", "registrarProfesorResponse");
    private final static QName _ListarProfesoresResponse_QNAME = new QName("http://services.cibertec.edu/", "listarProfesoresResponse");
    private final static QName _ListarProfesores_QNAME = new QName("http://services.cibertec.edu/", "listarProfesores");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: edu.cibertec.services
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ListarProfesores }
     * 
     */
    public ListarProfesores createListarProfesores() {
        return new ListarProfesores();
    }

    /**
     * Create an instance of {@link RegistrarProfesorResponse }
     * 
     */
    public RegistrarProfesorResponse createRegistrarProfesorResponse() {
        return new RegistrarProfesorResponse();
    }

    /**
     * Create an instance of {@link Profesor }
     * 
     */
    public Profesor createProfesor() {
        return new Profesor();
    }

    /**
     * Create an instance of {@link RegistrarProfesor }
     * 
     */
    public RegistrarProfesor createRegistrarProfesor() {
        return new RegistrarProfesor();
    }

    /**
     * Create an instance of {@link ListarProfesoresResponse }
     * 
     */
    public ListarProfesoresResponse createListarProfesoresResponse() {
        return new ListarProfesoresResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RegistrarProfesor }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.cibertec.edu/", name = "registrarProfesor")
    public JAXBElement<RegistrarProfesor> createRegistrarProfesor(RegistrarProfesor value) {
        return new JAXBElement<RegistrarProfesor>(_RegistrarProfesor_QNAME, RegistrarProfesor.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RegistrarProfesorResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.cibertec.edu/", name = "registrarProfesorResponse")
    public JAXBElement<RegistrarProfesorResponse> createRegistrarProfesorResponse(RegistrarProfesorResponse value) {
        return new JAXBElement<RegistrarProfesorResponse>(_RegistrarProfesorResponse_QNAME, RegistrarProfesorResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListarProfesoresResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.cibertec.edu/", name = "listarProfesoresResponse")
    public JAXBElement<ListarProfesoresResponse> createListarProfesoresResponse(ListarProfesoresResponse value) {
        return new JAXBElement<ListarProfesoresResponse>(_ListarProfesoresResponse_QNAME, ListarProfesoresResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListarProfesores }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.cibertec.edu/", name = "listarProfesores")
    public JAXBElement<ListarProfesores> createListarProfesores(ListarProfesores value) {
        return new JAXBElement<ListarProfesores>(_ListarProfesores_QNAME, ListarProfesores.class, null, value);
    }

}
