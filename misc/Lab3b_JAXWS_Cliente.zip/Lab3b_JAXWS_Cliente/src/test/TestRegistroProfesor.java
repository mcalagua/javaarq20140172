package test;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.namespace.QName;
import edu.cibertec.services.Profesor;
import edu.cibertec.services.ProfesoresService;
import edu.cibertec.services.ProfesoresServiceImplService;

public class TestRegistroProfesor {
	
	public static void main(String[] args) throws MalformedURLException, DatatypeConfigurationException {
		
		// Reference the URL
		URL url = new URL("http://localhost:8080/Lab3b_JAXWS_Servidor/?wsdl");
		
		//Qualified name of the service
		QName qName = new QName("http://services.cibertec.edu/", "ProfesoresServiceImplService");
		
		ProfesoresServiceImplService serviceFactory = new ProfesoresServiceImplService(url,qName);
		ProfesoresService servicePort = serviceFactory.getProfesoresServiceImplPort();
		
		Profesor profesor = new Profesor();
		profesor.setUsuario("jperez");
		profesor.setNombres("Juan");
		profesor.setApellidos("Perez");
		profesor.setFechaNacimiento(DatatypeFactory.newInstance().
						newXMLGregorianCalendar(new GregorianCalendar(1987,07,8)));
		
		System.out.println("Respuesta WS : " + servicePort.registrarProfesor(profesor) );
		
	}

}
