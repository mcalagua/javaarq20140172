package test;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.namespace.QName;
import edu.cibertec.services.Profesor;
import edu.cibertec.services.ProfesoresService;
import edu.cibertec.services.ProfesoresServiceImplService;

public class TestListadorProfesor {
	
	public static void main(String[] args) throws MalformedURLException, DatatypeConfigurationException {
		
		// Reference the URL
		URL url = new URL("http://localhost:8080/Lab3b_JAXWS_Servidor/?wsdl");
		
		//Qualified name of the service
		QName qName = new QName("http://services.cibertec.edu/", "ProfesoresServiceImplService");
		
		ProfesoresServiceImplService serviceFactory = new ProfesoresServiceImplService(url,qName);
		ProfesoresService servicePort = serviceFactory.getProfesoresServiceImplPort();

		List<Profesor> listado = servicePort.listarProfesores();
		
		System.out.println("------ Listado de profesores ------");
		for(Profesor profe : listado){
			
			System.out.println("ID:"+profe.getIdProfesor());
			System.out.println("Usuario:"+profe.getUsuario());
			System.out.println("Nombres:"+profe.getNombres());
			System.out.println("Apellidos:"+profe.getApellidos());
			System.out.println("FechaNacimiento:"+profe.getFechaNacimiento());
			System.out.println("------------------------------------");
		}	
	}
}
