package edu.cibertec.services.impl;


import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import edu.cibertec.entity.Link;
import edu.cibertec.entity.Programa;
import edu.cibertec.entity.Programas;
import edu.cibertec.services.ProgramasResource;

@Path("/programas")
public class ProgramasResourceService implements ProgramasResource {
	
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");

	@Override
	@GET
	@Produces({ "text/xml", "application/json" })
	public Programas getProgramas(@QueryParam("start") int start,
			@QueryParam("size") @DefaultValue("2") int size,
			@Context UriInfo uriInfo, @Context HttpHeaders httpHeaders) {
		
		EntityManager em = emf.createEntityManager();
		
		em.getTransaction().begin();
		
		List<Programa> listaProgramas =
				emf.createEntityManager().createQuery(" select p from Programa p", Programa.class).getResultList();
		
		Programas programas = new Programas();
		
		programas.setPrograms(listaProgramas);
		programas.setLinks(new ArrayList<Link>());
		
		em.close();

		return programas;
	}

	@Override
	@GET
	@Path("{id}")
	@Produces({ "text/xml", "application/json" })
	public Programa getPrograma(@PathParam("id") String idPrograma) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	@POST
	@Consumes({ "text/xml", "application/json" })
	public Response createPrograma(Programa programa) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	@PUT
	@Path("{id}")
	@Consumes("*/*")
	public Response uploadSyllabus(@PathParam("id") String idPrograma,
			byte[] inputStream) {
		// TODO Auto-generated method stub
		return null;
	}


}
