package edu.cibertec.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MysqlDBConn {
	
	private static final String DRIVER_CLASS = "com.mysql.jdbc.Driver";
	private static final String URL_CONNECTION = "jdbc:mysql://localhost:3306/JAAD";
	private static final String USER = "root";
	private static final String PASSWORD = "mysql";
	
	public static Connection getConnection(){

			Connection cn = null;
			
			try {
				Class.forName(DRIVER_CLASS);
				
				cn = DriverManager.
						getConnection(
								URL_CONNECTION,
								USER,
								PASSWORD);
				
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			return cn;
	
	}
	
	/*public static Connection getConnection(){

		Connection cn = null;
		
		try {
			
			Context ctx = new InitialContext();
			DataSource ds = (DataSource) ctx.lookup("jdbc/mysqlDS");
			cn = ds.getConnection();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (NamingException e) {
			e.printStackTrace();
		}
		
		return cn;

	}*/

}
