package edu.cibertec.handler;

import java.io.IOException;
import java.util.Set;

import javax.xml.namespace.QName;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPFault;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;
import javax.xml.ws.soap.SOAPFaultException;

import org.w3c.dom.NodeList;

public class AuthServerHandler
	implements SOAPHandler<SOAPMessageContext>{

	@Override
	public boolean handleMessage(
			SOAPMessageContext context) {
		
		System.out.println("AuthServerHandler");
		
		Boolean esRespuesta =
			(Boolean) 
			context.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY);
		
		if(!esRespuesta){

	try {
		
		SOAPMessage soapMessage = 
				context.getMessage();
		SOAPEnvelope soapEnvelope = 
				soapMessage.getSOAPPart().getEnvelope();
		SOAPHeader soapHeader = 
				soapEnvelope.getHeader();
		
		if(soapHeader == null || !soapHeader.
									hasChildNodes()){
			
			SOAPFault soapFault = 
				soapMessage.getSOAPPart().
				getEnvelope().getBody().addFault();
			
			soapFault.setFaultString(
					"El mensaje no tiene header");
			
			throw new SOAPFaultException(soapFault);	
		}
		
		NodeList nodos = 
				soapHeader.
				getElementsByTagNameNS(
						"http://security/","*");
		
		String usuario = "";
		String clave = "";
		
	for(int i=0 ; i<nodos.getLength(); i++){
		
		if(nodos.item(i).
				getLocalName().equals("user")){
			usuario = nodos.item(i).getTextContent();
		}	
		if(nodos.item(i).
				getLocalName().equals("password")){
			clave = nodos.item(i).getTextContent();
		}	
		System.out.println(
				nodos.item(i).getTextContent());	
	}
	
	if(usuario.equals("duke") &&
			clave.equals("java")){
		
		System.out.println("Autenticacion exitosa!!!");
		
	}else{		
		SOAPFault soapFault = 
				soapMessage.getSOAPPart().
				getEnvelope().getBody().addFault();		
			soapFault.setFaultString(
					"Credenciales invalidas");	
			throw new SOAPFaultException(soapFault);	
	}
		//Debug para el mensaje SOAP
		System.out.println("SOAPMessage");
		soapMessage.writeTo(System.out);
		
	} catch (SOAPException e) {
		e.printStackTrace();
	} catch (IOException e) {
		e.printStackTrace();
	}
	
	}
		//Prosiga la ejecucion del handler
		return true;
	}

	@Override
	public boolean handleFault(SOAPMessageContext context) {
		return false;
	}

	@Override
	public void close(MessageContext context) {
		
	}

	@Override
	public Set<QName> getHeaders() {
		return null;
	}

}
