package edu.cibertec.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;

import edu.cibertec.entity.Alumno;
import edu.cibertec.utils.MysqlDBConn;

@WebService(
		endpointInterface=
			"edu.cibertec.services.AlumnoService")
public class AlumnoServiceImpl 
	implements AlumnoService{

	@Override
	@WebMethod
	@WebResult(name = "respuesta")
	public String registrar(
			@WebParam(name = "alumno") Alumno alumno) {
	
		System.out.println("Metodo registrar alumno");
		
		String respuesta = "";
		Connection conexion = null;
		
		try {
			
		conexion = MysqlDBConn.getConnection();
		
		PreparedStatement pst =
			conexion.prepareStatement(
			"INSERT INTO " +
			"TB_ALUMNO (nombres,apellidos,fechaNacimiento) " +
			"values (?,?,?)");
			
		pst.setString(1, alumno.getNombres());
		pst.setString(2, alumno.getApellidos());
		pst.setDate(3, 
				new java.sql.Date(
				alumno.getFechaNacimiento().getTime()));
		
		int resultado = pst.executeUpdate();
		
		if(resultado == 1){
			respuesta = "Alumno registrado OK";
		}
			
		} catch (Exception e) {
			respuesta = e.getMessage();
			e.printStackTrace();
		} finally{			
			if(conexion!=null){
				try {
				conexion.close();
				} catch (SQLException e) {
				e.printStackTrace();
				}
			}	
		}
		return respuesta;
	}

	@Override
	@WebMethod
	@WebResult(name = "alumno")
	public List<Alumno> listarAlumnos() {

		return null;
	}

}
