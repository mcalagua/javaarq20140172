package test;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.namespace.QName;

import edu.cibertec.services.Alumno;
import edu.cibertec.services.AlumnoService;
import edu.cibertec.services.AlumnoServiceImplService;

public class TestRegistrarAlumno {

	public static void main(String[] args) 
			throws MalformedURLException, DatatypeConfigurationException {
		
		URL wsdl = 
				new URL("http://localhost:8080/Lab3d_JAXWS_WSSHandler/?wsdl");
		
		//targetNamespace del WSDL
		//name del WSDL
		QName qName = new QName(
				"http://services.cibertec.edu/", 
				"AlumnoServiceImplService");
		
		AlumnoServiceImplService serviceFactory =
				new AlumnoServiceImplService(
						wsdl, qName);
		
		AlumnoService service =
				serviceFactory.getAlumnoServiceImplPort();
		
		Alumno alumno = new Alumno();
		alumno.setNombres("Johann");
		alumno.setApellidos("Alvarado");
		alumno.setFechaNacimiento(		
			DatatypeFactory.newInstance().
			newXMLGregorianCalendar(
			new GregorianCalendar(1961, 02, 11))
		);
		
		String resultado = 
				service.registrar(alumno);
		
		System.out.println("Resultado : "+
						resultado);
	}
}
