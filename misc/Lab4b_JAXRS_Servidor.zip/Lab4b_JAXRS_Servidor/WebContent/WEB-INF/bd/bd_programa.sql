delimiter $$

CREATE DATABASE `JAAD` /*!40100 DEFAULT CHARACTER SET utf8 */$$

delimiter $$

CREATE TABLE `TB_PROFESOR` (
  `idProfesor` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(50) NOT NULL,
  `nombres` varchar(255) DEFAULT NULL,
  `apellidos` varchar(255) DEFAULT NULL,
  `fechaNacimiento` date DEFAULT NULL,
  PRIMARY KEY (`idProfesor`,`usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8$$

delimiter $$

CREATE TABLE `TB_PROGRAMA` (
  `idPrograma` varchar(50) NOT NULL,
  `nombre` varchar(255) DEFAULT NULL,
  `duracionHoras` double DEFAULT NULL,
  `horario` varchar(255) DEFAULT NULL,
  `fechaInicio` date DEFAULT NULL,
  `fechaFin` date DEFAULT NULL,
  PRIMARY KEY (`idPrograma`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8$$

INSERT INTO `TB_PROGRAMA` (`idPrograma`,`nombre`,`duracionHoras`,`horario`,`fechaInicio`,`fechaFin`) VALUES ('1365584841782-1','Java Fundamentals',150,'Martes y Jueves','2013-04-24','2013-07-24');
INSERT INTO `TB_PROGRAMA` (`idPrograma`,`nombre`,`duracionHoras`,`horario`,`fechaInicio`,`fechaFin`) VALUES ('1365585485517-1','Java Architect Application Developer',132,'Viernes y Sabados','2013-04-24','2013-07-24');
INSERT INTO `TB_PROGRAMA` (`idPrograma`,`nombre`,`duracionHoras`,`horario`,`fechaInicio`,`fechaFin`) VALUES ('1365658427412-1','Linux Enterprise Administrator & Security',120,'Lunes y Miercoles','2013-04-24','2013-07-24');
INSERT INTO `TB_PROGRAMA` (`idPrograma`,`nombre`,`duracionHoras`,`horario`,`fechaInicio`,`fechaFin`) VALUES ('1365662220050-1','cURL Tester',20,'Domingos','2013-04-24','2013-07-24');
INSERT INTO `TB_PROGRAMA` (`idPrograma`,`nombre`,`duracionHoras`,`horario`,`fechaInicio`,`fechaFin`) VALUES ('1365663256817-1','REST Application Developer',50,'Domingos','2013-05-08','2013-07-08');


