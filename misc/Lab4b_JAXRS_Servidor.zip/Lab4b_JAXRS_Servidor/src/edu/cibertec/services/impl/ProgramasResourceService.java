package edu.cibertec.services.impl;

import java.net.URI;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import javax.ws.rs.Path;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import edu.cibertec.entity.Programa;
import edu.cibertec.services.ProgramasResource;
import edu.cibertec.utils.MysqlDBConn;

@Path("/programas")
public class ProgramasResourceService 
	implements ProgramasResource{
	
	private AtomicInteger generadorId = new AtomicInteger();
	
	public List<Programa> getProgramas() {
		
		System.out.println("Listando programas ["+ this.hashCode() + "]");		
		List<Programa> listaProgramas = null;
		Connection connection = null;

		try {
			
			connection = MysqlDBConn.getConnection();		
			PreparedStatement pst = 
					connection.prepareStatement("SELECT * FROM TB_PROGRAMA");
			ResultSet rs = pst.executeQuery();
			listaProgramas = new ArrayList<Programa>();			
			Programa programa = null;
			
			while (rs.next()){
				programa = new Programa();				
				programa.setIdPrograma(rs.getString(1));
				programa.setNombre(rs.getString(2));
				programa.setDuracionHoras(rs.getDouble(3));
				programa.setHorario(rs.getString(4));
				programa.setFechaInicio(new Date(rs.getDate(5).getTime()));
				programa.setFechaFin(new Date(rs.getDate(6).getTime()));			
				listaProgramas.add(programa);
			}
			
		} catch (SQLException e) {	
			e.printStackTrace();		
		} finally{
	
			if(connection!=null){
				try { connection.close();} 
				catch (SQLException e) {e.printStackTrace();}
			}
			
		}
		return listaProgramas;	
	}

	public Programa getPrograma(String idPrograma) {
		
		System.out.println("Buscando programa "+ idPrograma + " ["+ 
										this.hashCode() + "]");	
		Connection connection = null;
		Programa programa = null;
		
		try {
			
			connection = MysqlDBConn.getConnection();		
			PreparedStatement pst = 
					connection.prepareStatement("SELECT * FROM TB_PROGRAMA " +
												"where idPrograma = ?");	
			pst.setString(1, idPrograma);
			ResultSet rs = pst.executeQuery();
				
			if (rs.next()){		
				programa = new Programa();				
				programa.setIdPrograma(rs.getString(1));
				programa.setNombre(rs.getString(2));
				programa.setDuracionHoras(rs.getDouble(3));
				programa.setHorario(rs.getString(4));
				programa.setFechaInicio(new Date(rs.getDate(5).getTime()));
				programa.setFechaFin(new Date(rs.getDate(6).getTime()));
			}else{				
				throw new WebApplicationException(
						Response.Status.NOT_FOUND);				
			}
			
		} catch (SQLException e) {	
			e.printStackTrace();		
		} finally{
	
			if(connection!=null){
				try { connection.close();} 
				catch (SQLException e) {e.printStackTrace();}
			}
			
		}
		
		return programa;
	}

	private String generaId(){		
		return System.currentTimeMillis() + "-" + generadorId.incrementAndGet();	
	}
	
	public Response createPrograma(Programa programa) {
		
		System.out.println("Registrando programa:"+ programa.getNombre() + 
				" ["+ this.hashCode() + "]");

		Connection connection = null;
		String idPrograma = generaId();

		try {
			
			connection = MysqlDBConn.getConnection();
			PreparedStatement pst =	
					connection.prepareStatement(
					"INSERT INTO " +
					"TB_PROGRAMA (idPrograma,nombre,duracionHoras,horario,fechaInicio,fechaFin) " +
					"values (?,?,?,?,?,?)");
			
			pst.setString(1, idPrograma);
			pst.setString(2, programa.getNombre());
			pst.setDouble(3, programa.getDuracionHoras());
			pst.setString(4, programa.getHorario());
			pst.setDate(5,new java.sql.Date(programa.getFechaInicio().getTime()));
			pst.setDate(6,new java.sql.Date(programa.getFechaFin().getTime()));
			
			int resultado = pst.executeUpdate();

			if (resultado != 1){
				throw new WebApplicationException(
						Response.Status.INTERNAL_SERVER_ERROR);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
	
			if(connection!=null){
				try { connection.close();} 
				catch (SQLException e) {e.printStackTrace();}
			}
		}
		
		return Response.created(URI.create(idPrograma)).build();
	}
	
}
