package edu.cibertec.services;

import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import edu.cibertec.entity.Profesor;

@WebService
public interface ProfesoresService {

	@WebMethod
	@WebResult(name="respuesta")
	public String registrarProfesor(
			@WebParam(name="profesor") Profesor profesor);
	
	@WebMethod
	@WebResult(name="profesor")
	public List<Profesor> listarProfesores();

}
