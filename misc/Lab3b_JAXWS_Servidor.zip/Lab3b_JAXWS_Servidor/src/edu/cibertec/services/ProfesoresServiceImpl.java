package edu.cibertec.services;

import edu.cibertec.entity.Profesor;
import edu.cibertec.utils.MysqlDBConn;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;

@WebService(endpointInterface = "edu.cibertec.services.ProfesoresService")
public class ProfesoresServiceImpl 
	implements ProfesoresService{

	@Override
	@WebMethod
	@WebResult(name = "respuesta")
	public String registrarProfesor(
			@WebParam(name = "profesor") Profesor profesor) {
		
		System.out.println("Registrando profesor " + profesor.getNombres());
		
		String respuesta = "";
		Connection connection = null;

		try {
			
			connection = MysqlDBConn.getConnection();
			
			PreparedStatement pst =	
					connection.prepareStatement(
					"INSERT INTO " +
					"TB_PROFESOR (usuario,nombres,apellidos,fechaNacimiento) " +
					"values (?,?,?,?)");
					
			pst.setString(1, profesor.getUsuario());
			pst.setString(2, profesor.getNombres());
			pst.setString(3, profesor.getApellidos());
			pst.setDate(4, new java.sql.Date(profesor.getFechaNacimiento().getTime()));
			
			int resultado = pst.executeUpdate();

			if (resultado == 1){
				respuesta = "Profesor registrado " + profesor.getUsuario();
			}
			
		} catch (SQLException e) {
			
			respuesta = e.getMessage();
			e.printStackTrace();
			
		} finally{
	
			if(connection!=null){
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			
		}
	
		return respuesta;
		
	}

	@Override
	@WebMethod
	@WebResult(name = "profesor")
	public List<Profesor> listarProfesores() {
		
		System.out.println("Listando profesores ");
		
		List<Profesor> listaProfesores = null;
		Connection connection = null;

		try {
			
			connection = MysqlDBConn.getConnection();
			
			PreparedStatement pst = 
					connection.prepareStatement("SELECT * FROM TB_PROFESOR");

			ResultSet rs = pst.executeQuery();
			
			listaProfesores = new ArrayList<Profesor>();
			
			Profesor profe = null;
			
			while (rs.next()){
				
				profe = new Profesor();
				profe.setIdProfesor(rs.getInt(1));
				profe.setUsuario(rs.getString(2));
				profe.setNombres(rs.getString(3));
				profe.setApellidos(rs.getString(4));			
				profe.setFechaNacimiento(new Date(rs.getDate(5).getTime()));
				
				listaProfesores.add(profe);
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		} finally{
	
			if(connection!=null){
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			
		}
		
		return listaProfesores;
		
	}


}
