package gch;

import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement
@XmlType(propOrder={"codigo","nombre","modulos","fechaInicio","fechaFin"})
public class Programa {
	
	private Integer codigo;
	private String nombre;
	private List<String> modulos;
	private Date fechaInicio;
	private Date fechaFin;
	
	@XmlAttribute
	public Integer getCodigo() {
		return codigo;
	}
	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}
	
	@XmlElement(name="nombreComercial")
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
    @XmlElementWrapper(name="modulos")
    @XmlElement(name="modulo")
	public List<String> getModulos() {
		return modulos;
	}
	public void setModulos(List<String> modulos) {
		this.modulos = modulos;
	}
	public Date getFechaInicio() {
		return fechaInicio;
	}
	public void setFechaInicio(Date fechaInicio) {
		this.fechaInicio = fechaInicio;
	}
	public Date getFechaFin() {
		return fechaFin;
	}
	public void setFechaFin(Date fechaFin) {
		this.fechaFin = fechaFin;
	}

}
