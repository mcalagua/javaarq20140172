package gch;

import java.io.File;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

public class JAXBUnMarshall {
	
	public static void main(String[] args) {
		
		 try {
			 
			 	File programaXML = new File("/home/tmp/programa.xml");
			 
				JAXBContext jaxbContext = JAXBContext.newInstance(Programa.class);
		 
				Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();		
				//jaxbUnmarshaller.setProperty(Marshaller.JAXB_ENCODING, "iso-8859-1");
				
				Programa programa = (Programa) jaxbUnmarshaller.unmarshal(programaXML);
				
				System.out.println("----------Datos del programa--------------");
				System.out.println("Codigo: " + programa.getCodigo());
				System.out.println("Nombre: " + programa.getNombre());
				System.out.println("Modulos: " + programa.getModulos());
				System.out.println("FechaInicio: " + programa.getFechaFin());
				System.out.println("FechaFin: " + programa.getFechaFin());

			  } catch (JAXBException e) {
				e.printStackTrace();
			  }
		
	}

}
