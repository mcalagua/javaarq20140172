package gch;

import java.io.File;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;

public class JAXBMarshall {


	public static void main(String[] args) {
		
		Programa programa = new Programa();
		
		programa.setCodigo(2452);
		programa.setNombre("Java Architect Application Developer");
		programa.setModulos(new ArrayList<String>(){
			{
				add("Fundamentos de Comunicación en sistemas distribuidos");
				add("Arquitectura de Web Services y estándares utilizados");
			}
		});
		programa.setFechaInicio(new GregorianCalendar(2013, 0, 22).getTime());
		programa.setFechaFin(new GregorianCalendar(2013, 2, 25).getTime());
		
		try {
			
			File programaXML = new File("/home/tmp/programa.xml");
			
			JAXBContext jaxbContext = JAXBContext.newInstance(Programa.class);
			Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
			
			// output pretty printed
			jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			//jaxbMarshaller.setProperty(Marshaller.JAXB_ENCODING, "iso-8859-1");
					
			jaxbMarshaller.marshal(programa, programaXML);
			jaxbMarshaller.marshal(programa, System.out);
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
